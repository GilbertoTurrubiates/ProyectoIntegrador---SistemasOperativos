class Proceso:
    def __init__(self, pid, prioridad, tiempo_ejecucion):
        self.pid = pid
        self.estado = "listo"
        self.prioridad = prioridad
        self.tiempo_ejecucion = tiempo_ejecucion
        self.recursos = {"cpu": 0, "memoria": 0}
        self.mensajes = []
        self.causa_terminacion = None

    def __str__(self):
        return f"Proceso {self.pid} | Estado: {self.estado} | Prioridad: {self.prioridad} | Tiempo: {self.tiempo_ejecucion} | Recursos: {self.recursos}"

    def enviar_mensaje(self, mensaje, destino):
        destino.mensajes.append(mensaje)
        print(f"Proceso {self.pid} envió mensaje '{mensaje}' a Proceso {destino.pid}")

    def recibir_mensaje(self):
        if self.mensajes:
            mensaje = self.mensajes.pop(0)
            print(f"Proceso {self.pid} recibió mensaje: '{mensaje}'")
            return mensaje
        return None

    def terminar(self, causa):
        self.estado = "terminado"
        self.causa_terminacion = causa
        print(f"Proceso {self.pid} terminó por: {causa}")


class GestorRecursos:
    def __init__(self):
        self.cpu_disponible = 1
        self.memoria_disponible = 4096

    def solicitar_recursos(self, proceso, cpu, memoria):
        if self.cpu_disponible >= cpu and self.memoria_disponible >= memoria:
            self.cpu_disponible -= cpu
            self.memoria_disponible -= memoria
            proceso.recursos["cpu"] += cpu
            proceso.recursos["memoria"] += memoria
            print(f"Proceso {proceso.pid} recibió CPU: {cpu}, Memoria: {memoria}")
            return True
        else:
            print(f"Proceso {proceso.pid}: No hay suficientes recursos")
            return False

    def liberar_recursos(self, proceso):
        self.cpu_disponible += proceso.recursos["cpu"]
        self.memoria_disponible += proceso.recursos["memoria"]
        print(f"Proceso {proceso.pid} liberó CPU: {proceso.recursos['cpu']}, Memoria: {proceso.recursos['memoria']}")
        proceso.recursos["cpu"] = 0
        proceso.recursos["memoria"] = 0


class Planificador:
    def __init__(self, algoritmo, quantum=2):
        self.cola_listos = []
        self.proceso_actual = None
        self.algoritmo = algoritmo
        self.quantum = quantum
        self.tiempo_total = 0

    def agregar_proceso(self, proceso):
        self.cola_listos.append(proceso)
        proceso.estado = "listo"
        print(f"Proceso {proceso.pid} añadido a la cola de listos")

    def ejecutar(self, gestor_recursos):
        if not self.cola_listos and not self.proceso_actual:
            print("No hay procesos para ejecutar")
            return False

        if not self.proceso_actual:
            self.seleccionar_proceso()

        if self.proceso_actual:
            if gestor_recursos.solicitar_recursos(self.proceso_actual, 1, 1000):
                self.proceso_actual.estado = "ejecutando"
                print(f"Ejecutando {self.proceso_actual}")

                if self.algoritmo == "RR":
                    tiempo_corrido = min(self.quantum, self.proceso_actual.tiempo_ejecucion)
                else:
                    tiempo_corrido = self.proceso_actual.tiempo_ejecucion

                self.proceso_actual.tiempo_ejecucion -= tiempo_corrido
                self.tiempo_total += tiempo_corrido

                if self.proceso_actual.tiempo_ejecucion <= 0:
                    self.proceso_actual.terminar("Finalización normal")
                    gestor_recursos.liberar_recursos(self.proceso_actual)
                    self.proceso_actual = None
                else:
                    if self.algoritmo == "RR":
                        self.proceso_actual.estado = "listo"
                        self.cola_listos.append(self.proceso_actual)
                        self.proceso_actual = None

        return True

    def seleccionar_proceso(self):
        if not self.cola_listos:
            return

        if self.algoritmo == "FCFS":
            self.proceso_actual = self.cola_listos.pop(0)
        elif self.algoritmo == "SJF":
            self.proceso_actual = min(self.cola_listos, key=lambda p: p.tiempo_ejecucion)
            self.cola_listos.remove(self.proceso_actual)
        elif self.algoritmo == "Prioridad":
            self.proceso_actual = min(self.cola_listos, key=lambda p: p.prioridad)
            self.cola_listos.remove(self.proceso_actual)
        elif self.algoritmo == "RR":
            self.proceso_actual = self.cola_listos.pop(0)

    def terminar_proceso(self, pid, gestor_recursos):
        for proceso in self.cola_listos:
            if proceso.pid == pid:
                proceso.terminar("Terminación forzada")
                self.cola_listos.remove(proceso)
                gestor_recursos.liberar_recursos(proceso)
                return True
        if self.proceso_actual and self.proceso_actual.pid == pid:
            self.proceso_actual.terminar("Terminación forzada")
            gestor_recursos.liberar_recursos(self.proceso_actual)
            self.proceso_actual = None
            return True
        print(f"Proceso {pid} no encontrado")
        return False


class Semaforo:
    def __init__(self, valor_inicial):
        self.valor = valor_inicial

    def wait(self, proceso):
        self.valor -= 1
        if self.valor < 0:
            proceso.estado = "esperando"
            print(f"Proceso {proceso.pid} está esperando en el semáforo")
            return False
        return True

    def signal(self, proceso):
        self.valor += 1
        print(f"Proceso {proceso.pid} liberó el semáforo")
        if self.valor <= 0:
            return True
        return False


import os


class Simulador:
    def __init__(self):
        self.gestor = GestorRecursos()
        self.planificador = None
        self.pid_counter = 1
        self.logs = []

    def log_evento(self, mensaje):
        self.logs.append(mensaje)
        print(mensaje)

    def mostrar_menu(self):
        os.system('cls' if os.name == 'nt' else 'clear')
        print("=== Simulador de Gestor de Procesos ===")
        print("1. Seleccionar algoritmo de planificación")
        print("2. Crear proceso")
        print("3. Listar procesos")
        print("4. Listar recursos disponibles")
        print("5. Ejecutar un ciclo")
        print("6. Terminar proceso")
        print("7. Suspender proceso")
        print("8. Reanudar proceso")
        print("9. Mostrar logs")
        print("10. Salir")
        return input("Elige una opción: ")

    def seleccionar_algoritmo(self):
        print("Algoritmos disponibles: FCFS, SJF, Prioridad, RR")
        algoritmo = input("Ingresa el algoritmo: ").upper()
        if algoritmo in ["FCFS", "SJF", "PRIORIDAD", "RR"]:
            quantum = 2
            if algoritmo == "RR":
                quantum = int(input("Ingresa el quantum: "))
            self.planificador = Planificador(algoritmo, quantum)
            self.log_evento(f"Algoritmo seleccionado: {algoritmo}")
        else:
            print("Algoritmo no válido")

    def crear_proceso(self):
        prioridad = int(input("Ingresa la prioridad (1-10): "))
        tiempo = int(input("Ingresa el tiempo de ejecución: "))
        proceso = Proceso(self.pid_counter, prioridad, tiempo)
        self.planificador.agregar_proceso(proceso)
        self.log_evento(f"Proceso {self.pid_counter} creado")
        self.pid_counter += 1

    def listar_procesos(self):
        print("Procesos en la cola de listos:")
        for proceso in self.planificador.cola_listos:
            print(proceso)
        if self.planificador.proceso_actual:
            print("Proceso actual:")
            print(self.planificador.proceso_actual)

    def listar_recursos(self):
        print(f"CPU disponible: {self.gestor.cpu_disponible}")
        print(f"Memoria disponible: {self.gestor.memoria_disponible} MB")

    def ejecutar_ciclo(self):
        if self.planificador:
            self.planificador.ejecutar(self.gestor)
        else:
            print("Selecciona un algoritmo primero")

    def terminar_proceso(self):
        pid = int(input("Ingresa el PID del proceso: "))
        if self.planificador:
            self.planificador.terminar_proceso(pid, self.gestor)
        else:
            print("Selecciona un algoritmo primero")

    def suspender_proceso(self):
        pid = int(input("Ingresa el PID del proceso: "))
        if self.planificador and self.planificador.proceso_actual and self.planificador.proceso_actual.pid == pid:
            self.planificador.proceso_actual.estado = "esperando"
            self.planificador.cola_listos.append(self.planificador.proceso_actual)
            self.log_evento(f"Proceso {pid} suspendido")
            self.planificador.proceso_actual = None
        else:
            print("Proceso no encontrado o no está ejecutando")

    def reanudar_proceso(self):
        pid = int(input("Ingresa el PID del proceso: "))
        for proceso in self.planificador.cola_listos:
            if proceso.pid == pid and proceso.estado == "esperando":
                proceso.estado = "listo"
                self.log_evento(f"Proceso {pid} reanudado")
                return
        print("Proceso no encontrado o no está suspendido")

    def mostrar_logs(self):
        print("=== Logs de eventos ===")
        for log in self.logs:
            print(log)

    def correr(self):
        while True:
            opcion = self.mostrar_menu()
            if opcion == "1":
                self.seleccionar_algoritmo()
            elif opcion == "2":
                if self.planificador:
                    self.crear_proceso()
                else:
                    print("Selecciona un algoritmo primero")
            elif opcion == "3":
                if self.planificador:
                    self.listar_procesos()
                else:
                    print("Selecciona un algoritmo primero")
            elif opcion == "4":
                self.listar_recursos()
            elif opcion == "5":
                self.ejecutar_ciclo()
            elif opcion == "6":
                self.terminar_proceso()
            elif opcion == "7":
                self.suspender_proceso()
            elif opcion == "8":
                self.reanudar_proceso()
            elif opcion == "9":
                self.mostrar_logs()
            elif opcion == "10":
                print("Saliendo del simulador")
                break
            else:
                print("Opción no válida")
            input("Presiona Enter para continuar...")


simulador = Simulador()
simulador.correr()
